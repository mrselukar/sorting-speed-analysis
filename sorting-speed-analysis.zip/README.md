# sorting-speed-analysis
A Simple Scripts that alalyzes the sorting speed of various sorting algorithms 
### Instructions to run on other machines 
Since the project was written in a jupyter notebook it is preferred that other users ahould do the same 
##### For Jupyter Notebook
Install Jupyter Notebook and start the server open the attached .ipynb file and execute all cells 
PS : THe preferred methord for jupyter notebook install is using anaconda 
##### On terminal 
Open Terminal and navigate to the current working directory and type 
python3 code_file.py

The output graphs are stored in the current working directord in high resolution 
The current maximum list length is set to 10000 (recursion depth for quick sort)
To Change the starting length no of X points and step find the no_of_x_points = 20
min_x_point = 1000 and x_step = 250 variable. The Current values are as mentioned above.

project by Mayur Selukar 
